/**
 * Implements 2 stacks with 1 array
 *
 */
public class Stack {
	
	int[] stacks;
	int top1;
	int top2;
	int n;//size of the stack

	/**
	 *
	 * Creates 2 stacks
	 * @param n - the size of both stacks combined
	 *
	 */
	public Stack(int size){

		stacks = new int[size];
		top1 = -1;
		top2 = size;
		n = size;
	}

	/**
	 * Pop an element off of stack 1
	 * @return int - the element off the top of stack 1
	 */
    public int pop1() throws EmptyStackException{
        
    	if(!isEmpty1()){
        	top1 = top1 - 1;            
    		return stacks[top1 +1]; 
    	}      		
		throw new EmptyStackException("Stack 1 is empty"); 		  		
    }
    
    /**
	 * Pop an element off of stack 2
	 * @return int - the element off the top of stack 2
	 */
    public int pop2() throws EmptyStackException{
            
        if(!isEmpty2()){
        	top2 = top2 + 1;
    		return stacks[top2 - 1]; 	  		
    	}
    	throw new EmptyStackException("Stack 2 is empty");
    }
    
    /**
	 * Push an element on stack 1
	 */    
    public void push1(int i){	
    	
    	if((size1() + size2()) == (n-1)){
    		System.out.println("stack 1 is full");
    		return;
    	}
    	top1++;
    	stacks[top1] = i;
    	
    }
   
    /**
	 * Push an element on stack 2
	 */ 
    public void push2(int i){
    	
    	if((size1() + size2()) == (n-1)){
    		System.out.println("stack 2 is full");
    		return;
    	}
    	top2--;
    	stacks[top2] = i;
    	
    }
	
	/**
	 * @return int - the size of stack 1
	 */
	public int size1(){
		
		return top1;
	}
	
	/**
	 * @return int - the size of stack 2
	 */
	public int size2(){
		return n - top2;
	}
	
	/**
	 * @return boolean - true if stack 1 is empty false other wise
	 */
	public boolean isEmpty1(){
		
		 if(top1 == -1){
            return true;        
        }
	
		return false;
	}
	
	/**
	 * @return boolean - true if stack 2 is empty false other wise
	 */
	public boolean isEmpty2(){
		    
		if(top2 == n){
       		return true;	
       	}
		
		return false;
	}


	/**
	 * Peek top of stack 1
	 * @return int - the element off the top of stack 1
	 */
    public int peek1() throws EmptyStackException{
        
    	if(!isEmpty1()){            
    		return stacks[top1]; 
    	}      		
		throw new EmptyStackException("Stack is empty");  		  		
    }
    
    /**
	 * Peek top of stack 2
	 * @return int - the element off the top of stack 2
	 */
    public int peek2() throws EmptyStackException{
            
        if(!isEmpty2()){
    		return stacks[top2]; 	  		
    	}
    	throw new EmptyStackException("Stack is empty");
    }


}
