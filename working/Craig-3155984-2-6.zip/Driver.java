

public class Driver {
    
    public static void main(String[] args) {

	
	Stack s = new Stack(6);
	
	s.push1(1);
	s.push1(2);
	s.push1(3);
	
	s.push2(4);
	s.push2(5);
	s.push2(6);
	
	s.push1(1);
	s.push2(1);
	
	try{
	
	System.out.println("stack1");
	
	System.out.println(s.pop1());
	System.out.println(s.pop1());
	System.out.println(s.pop1());
	
	System.out.println("stack2");
	
	System.out.println(s.pop2());
	System.out.println(s.pop2());
	System.out.println(s.pop2());
	
	s.pop2();
	
	}
	
	catch(Exception e){
		System.out.println(e.toString());
		
	}

    }
}
