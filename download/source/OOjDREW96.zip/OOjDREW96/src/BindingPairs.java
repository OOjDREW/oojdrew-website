
public class BindingPairs {


	
}
