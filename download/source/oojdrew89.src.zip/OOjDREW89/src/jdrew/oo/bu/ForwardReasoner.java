// OO jDREW Version 0.89
// Copyright (c) 2005 Marcel Ball
//
// This software is licensed under the LGPL (LESSER GENERAL PUBLIC LICENSE) License.
// Please see "license.txt" in the root directory of this software package for more details.
//
// Disclaimer: Please see disclaimer.txt in the root directory of this package.

package jdrew.oo.bu;

import java.util.*;

import jdrew.oo.bu.builtins.*;
import jdrew.oo.builtins.*;
import jdrew.oo.util.*;
import org.apache.log4j.*;

/**
 * This class implements the forward reasoner (bottom-up) modules of OO jDREW;
 * The unifier for this module is implemented by the jdrew.oo.bu.Unifier class
 * and a subsumption checking system is implemented by the
 * jdrew.oo.bu.Subsumption Class.
 *
 * A forward reasoner works by processing "new" facts; As each new fact is
 * processed unificiation with all previously exisiting rules is attempted;
 * if the unification is successful one of two things happens: if the resolvent
 * is a fact then it is added to the end of the new facts list; if the resolvent
 * is a rule then it is processed (attempting unification with all processed
 * facts) and is then added to the list of rules.
 *
 * <p>Title: OO jDREW</p>
 *
 * <p>Description: Reasoning Engine for the Semantic Web - Supporting OO RuleML
 * 0.88</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * @author Marcel A. Ball
 * @version 0.89
 */
public class ForwardReasoner {

    /**
     * This Hashtable stores all known facts that have already been processed.
     * The facts are indexed by the predicate name of the head (only) atom of
     * the facts.
     *
     * For each predicate that has been used there is a key->value pair in the
     * hash table; where the key is the integer code for the predicate symbol
     * (in the form of an Integer object) and the value is a Vector containing
     * the DefiniteClause objects for all processed facts with that predicate
     * symbol.
     */
    private Hashtable oldFacts;

    /**
     * This Hashtable stores all known rules in the knowledge base (both those
     * provided and those that have been derived). The rules are indexed by the
     * predicate name of the first atom in the body of the rule.
     *
     * For each predicate that has been used there is a key->value pair in the
     * hash table; where the key is the integer code for the predicate symbol
     * (in the form of an Integer object) and the value is a Vector containing
     * the DefiniteClause objects for all processed facts with that predicate
     * symbol.
     */
    private Hashtable rules;

    /**
     * This Vector contains all new facts that have not yet been processed.
     */
    private Vector newFacts;

    /**
     * This Hashtable contains references to all registered built-ins (the
     * default built-ins are registered with the engine at the time of object
     * creation).
     *
     * The built-ins are stored as a key->value pair in the hash table; where
     * the integer code for the built-in predicate name (as an Integer object)
     * is the key and the object that implements the built-in (this will be
     * either a sub-class of BUBuiltin or a Class that implements the
     * jdrew.oo.builtins.Builtin interface and is wrapped in a BUBuiltin by
     * the system) is the value.
     *
     * User created built-ins can be registered with calls to
     * registerBuiltin(jdrew.oo.builtins.Builtin) [in the case of a generic
     * built-in] or registerBuiltin(jdrew.oo.bu.builtins.BUBuiltin) [in the
     * case of a BU specific built-in that requires access to the engine
     * data structures].
     */
    private Hashtable builtins;

    Logger logger = Logger.getLogger("jdrew.oo.bu.ForwardReasoner");

    /**
     * This method constructs a new ForwardReasoner object (implementation of
     * a bottom-up reasoning engine); creating the required buffers for
     * knowledge base storage (oldFacts and rules Hashtable's and newFacts
     * Vector) and registers the system provided built-in relations with the
     * engine by calling the registerBuiltins();
     */
    public ForwardReasoner() {
        super();
        oldFacts = new Hashtable();
        rules = new Hashtable();
        builtins = new Hashtable();

        newFacts = new Vector();
        registerBuiltins();
    }

    /**
     * Allows user code to access the newFacts vector. Users may want to use
     * this in their code to allow the display of information in the knowledge
     * base.
     *
     * @return Vector A reference to the newFacts Vector for this bottom-up
     * reasoning engine.
     */
    public Vector getNewFacts() {
        return newFacts;
    }

    /**
     * Allows user code to access the oldFacts hash table. Users may want to
     * use this in their code to allow the display of information in the
     * knowledge base.
     *
     * @return Hashtable A reference to the oldFacts Hashtable for this
     * bottom-up reasoning engine.
     */
    public Hashtable getOldFacts() {
        return oldFacts;
    }

    /**
     * Allows user code to access the rules hash table. Users may want to use
     * this in their code to allow the display of information in the knowledge
     * base.
     *
     * @return Hashtable A reference to the oldFacts Hashtable for this
     * bottom-up reasoning engine.
     */
    public Hashtable getRules() {
        return rules;
    }

    /**
     * This method registers all of the standard built-in relations that are
     * included with the OO jDREW system with the created reasoning engine.
     */
    private void registerBuiltins() {
        this.registerBuiltin(new AssertBuiltin(this));
        this.registerBuiltin(new jdrew.oo.builtins.AbsBuiltin());
        this.registerBuiltin(new AddBuiltin());
        this.registerBuiltin(new CeilingBuiltin());
        this.registerBuiltin(new ContainsBuiltin());
        this.registerBuiltin(new ContainsIgnoreCaseBuiltin());
        this.registerBuiltin(new CosBuiltin());
        this.registerBuiltin(new DivideBuiltin());
        this.registerBuiltin(new EndsWithBuiltin());
        this.registerBuiltin(new EqualBuiltin());
        this.registerBuiltin(new FloorBuiltin());
        this.registerBuiltin(new GreaterThanBuiltin());
        this.registerBuiltin(new GreaterThanOrEqualBuiltin());
        this.registerBuiltin(new IntegerDivideBuiltin());
        this.registerBuiltin(new LessThanBuiltin());
        this.registerBuiltin(new LessThanOrEqualBuiltin());
        this.registerBuiltin(new ModBuiltin());
        this.registerBuiltin(new MultiplyBuiltin());
        this.registerBuiltin(new NotEqualBuiltin());
        this.registerBuiltin(new PowBuiltin());
        this.registerBuiltin(new RoundBuiltin());
        this.registerBuiltin(new SinBuiltin());
        this.registerBuiltin(new StartsWithBuiltin());
        this.registerBuiltin(new StringConcatBuiltin());
        this.registerBuiltin(new StringEqualIgnoreCaseBuiltin());
        this.registerBuiltin(new StringLengthBuiltin());
        this.registerBuiltin(new StringLowerCaseBuiltin());
        this.registerBuiltin(new StringUpperCaseBuiltin());
        this.registerBuiltin(new SubstringBuiltin());
        this.registerBuiltin(new SubtractBuiltin());
        this.registerBuiltin(new TanBuiltin());
    }

    /**
     * This method is used to register a new user created built-in with the
     * reasoning engine. This version of the method is for those built-ins that
     * implement the jdrew.oo.builtins.Builtin interface (these can be used
     * with both the bottom-up and the top-down engine).
     *
     * If the built-in that is being created requires access to the data
     * structures of the reasoning engine it should instead extend the
     * jdrew.oo.bu.builtins.BUBuiltin class and be registered with the
     * registerBuiltin(BUBuiltin) method.
     *
     * @param b Builtin An instance of the class that implements the built-in
     * relation; this should implement the jdrew.oo.builtins.Builtin interface.
     */
    public void registerBuiltin(jdrew.oo.builtins.Builtin b) {
        registerBuiltin(new BUBuiltin(b));
    }

    /**
     * This method is used to register a new user created built-in with the
     * reasoning engine. This version of the method is for those built-ins that
     * extend the jdrew.oo.bu.builtins.BUBuiltin class (those specific to the
     * bottom-up engine).
     *
     * @param b BUBuiltin An instance of the class that implements the built-in
     * relation; this should be a sub-class of the
     * jdrew.oo.bu.builtins.BUBuiltin class.
     */
    public void registerBuiltin(BUBuiltin b) {
        Integer sym = new Integer(b.getSymbol());
        builtins.put(sym, b);
    }

    /**
     * This method will print the entire knowledge base that has been loaded
     * into this reasoning engine to standard out. The output is divided into
     * three sections: new unprocessed facts; old process facts and rules.
     */
    public void printClauses() {
        System.out.println("New Facts: ");
        Iterator it = newFacts.iterator();
        int i = 1;
        while (it.hasNext()) {
            DefiniteClause dc = (DefiniteClause) it.next();
            System.out.println(i + ": " + dc.toPOSLString());
            i++;
        }

        System.out.println("\n\nOld Facts: ");
        Enumeration keys = oldFacts.keys();
        i = 1;
        while (keys.hasMoreElements()) {
            Integer key = (Integer) keys.nextElement();
            Vector v = (Vector) oldFacts.get(key);
            it = v.iterator();
            while (it.hasNext()) {
                DefiniteClause dc = (DefiniteClause) it.next();
                System.out.println(i + ": " + dc.toPOSLString());
                i++;
            }
        }

        System.out.println("\n\nRules: ");
        keys = rules.keys();
        i = 1;
        while (keys.hasMoreElements()) {
            Integer key = (Integer) keys.nextElement();
            Vector v = (Vector) rules.get(key);
            it = v.iterator();
            while (it.hasNext()) {
                DefiniteClause dc = (DefiniteClause) it.next();
                System.out.println(i + ": " + dc.toPOSLString());
                i++;
            }
        }

    }

    /**
     * This method is used to load clauses into the reasoning engine. This will
     * process each clause as it is loaded - placing new facts into the new
     * facts list and processing new rules against all exisiting processed
     * facts.
     *
     * @param it Iterator An iterator containing the new clauses to be loaded;
     * this should only iterate over DefiniteClause objects. These iterators
     * can be created by calling the iterator() method of parsers - such as
     * RuleMLParser or POSLParser.
     */
    public void loadClauses(Iterator it) {
        while (it.hasNext()) {
            DefiniteClause dc = (DefiniteClause) it.next();
            process(dc);
        }
    }

    /**
     * This method runs the main forward reasoner; causing the engine to find
     * all possible conclusions from the knowledge base that was loaded into
     * the engine.
     *
     * Bellow is the main process of the system.
     *
     * As long as there is a new fact in the newFacts list remove the first
     * fact from the list.
     *
     * Check to see if this fact is subsumed by another already processed fact
     * (oldFacts); if it is subsumed, discard the fact and move to the next
     * fact in the list.
     *
     * Add the fact to the old fact table.
     *
     * Find all rules that may be possible unification matches with the newly
     * selected fact. Attempt unification with each possible rule; if the
     * unification succeeds then build the resolvent and call the
     * process(DefiniteClause) method passing the newly created resolvent.
     */
    public void runForwardReasoner() {

        while (newFacts.size() > 0) {
            DefiniteClause dc = (DefiniteClause) newFacts.remove(0);

            logger.debug("Processing " + dc.toPOSLString());

            if (this.isSubsumed(dc)) {
                // If this new fact is subsumed by an old fact ignore and go to next new fact
                continue;

            }
            Integer sym = new Integer(dc.atoms[0].getSymbol());

            if (oldFacts.containsKey(sym)) { // add new fact to oldFact "list"
                Vector v = (Vector) oldFacts.get(sym);
                v.add(dc);
            } else {
                Vector v = new Vector();
                v.add(dc);
                oldFacts.put(sym, v);
            } // end adding new fact to oldFact "List"

            ArrayList al = new ArrayList();

            if (rules.containsKey(sym)) {
                // Rules with the same relation symbol - possible unifications
                Vector v = (Vector) rules.get(sym);
                Iterator it = v.iterator();
                while (it.hasNext()) {
                    // go though all possible unifications, and try to unify
                    DefiniteClause rule = (DefiniteClause) it.next();
                    logger.debug("Unifying with rule " + rule.toPOSLString());

                    Unifier u = new Unifier(dc, rule);
                    if (u.unifies()) {
                        // new fact unifies with a rule - process the resolvent
                        DefiniteClause r = u.resolvent();
                        logger.debug("Unified - resolvent: " + r.toPOSLString());
                        al.add(r);
                    }
                }

                it = al.iterator();
                while(it.hasNext())
                    process((DefiniteClause)it.next());
            }
        }
    }

    /**
     * This method is used to determine if a newly selected fact is subsumed
     * by another fact that has already been processed by the system.
     *
     * @param fact DefiniteClause This is the newly selected fact to perform
     * the subsumption check on.
     *
     * @return boolean Returns true if the fact is subsumed by another
     * processed fact; false otherwise. If this returns true (is subsumed) then
     * the input fact should be discarded as there is another already processed
     * fact which is more general than the newly selected fact.
     */
    private boolean isSubsumed(DefiniteClause fact) {
        Subsumption s = new Subsumption(fact);
        Integer sym = new Integer(fact.atoms[0].getSymbol());
        if (oldFacts.containsKey(sym)) {
            Vector v = (Vector) oldFacts.get(sym);
            Iterator it = v.iterator();
            while (it.hasNext()) {
                DefiniteClause dc = (DefiniteClause) it.next();
                if (s.subsumedBy(dc)) {
                    logger.info(fact.toPOSLString() + " is subsumed by " +
                                dc.toPOSLString());
                    return true;
                }

            }
        }

        return false;
    }

    /**
     * This method is used to an iterator over all clauses that may unify with
     * the specified atom in the given clause.
     *
     * The first step in the process is to retrieve the atom that is to be
     * considered for unification and access the predicate symbol.
     *
     * Once the predicate symbol is retrieved the system checks to see if there
     * is a built-in relation registered for that predicate symbol; if there is
     * the the clause and atom index are passed to the built-in implementation
     * for it to generate the appropriate response.
     *
     * If there is no built-in registered for that predicate the system will
     * retrieve any processed facts with that predicate symbol; these will be
     * returned (as an iterator) to check if they unify with the clause.
     *
     * @param dc2 DefiniteClause The clause to find possible unifying facts for.
     *
     * @param term int The index to the atom to search on (0 is the head, 1 to
     * n-1 are the atoms of the body); typically this is always a 1.
     *
     * @return Iterator An iterator over all clauses that may unify with the
     * specified atom of the passed clause.
     */
    private Iterator getUnifiableIterator(DefiniteClause dc2, int term) {
        Term t = dc2.atoms[term];
        Integer sym = new Integer(t.getSymbol());
        if (builtins.containsKey(sym)) {
            BUBuiltin b = (BUBuiltin) builtins.get(sym);
            Vector v = b.buildResult(dc2, term);
            return v.iterator();
        } else if (oldFacts.containsKey(sym)) {
            Vector ofs = (Vector) oldFacts.get(sym);
            return ofs.iterator();
        } else {
            // Not a built-in and no facts to consider for unification
            Vector v = new Vector();
            return v.iterator();
        }
    }

    /**
     * This method is used to process new clauses - either when loading them
     * or when a new rule is generated in a resolution step.
     *
     * If the new clause is a fact it is simply added to the new facts list.
     *
     * If the new clause is a rule then it is processed against all previously
     * used facts (oldFacts). This processing is done in two stages: first all
     * oldFacts that can possibly unify with the new rule are selected from the
     * oldFacts table; then unification is attempted with each of those facts
     * and if successful the resolvent is added to the newResults list. Once
     * all of the old facts have been tried then the system will iterate through
     * the newResults list and process each of the new resolvents by calling
     * the process(DefiniteClause) method recursively.
     *
     * @param dc DefiniteClause This should be the new clause to process; this
     * can either be a clause as it is loaded; or a newly generated resolvent in
     * the process(DefiniteClause) method or the runForwardReasoner() method.
     */
    private void process(DefiniteClause dc) {

        if (dc.atoms.length == 1) {
            newFacts.add(dc);
        } else {
            logger.debug("Processing " + dc.toPOSLString());

            Vector newResults = new Vector();

            Integer sym = new Integer(dc.atoms[1].getSymbol());
            Iterator ofsit = getUnifiableIterator(dc, 1);
            while (ofsit.hasNext()) {
                DefiniteClause oldfact = (DefiniteClause) ofsit.next();
                Unifier u = new Unifier(oldfact, dc);
                logger.debug("Unifying new rule " + dc.toPOSLString() +
                             " with old fact " + oldfact.toPOSLString());
                if (u.unifies()) {
                    DefiniteClause nr = u.resolvent();
                    newResults.add(nr);
                    logger.debug("Unified - resolvent: " + nr.toPOSLString());
                }
            }

            Iterator nrit = newResults.iterator();
            while (nrit.hasNext()) {
                DefiniteClause dc2 = (DefiniteClause) nrit.next();
                process(dc2);
            }

            if (rules.containsKey(sym)) {
                Vector v = (Vector) rules.get(sym);
                v.add(dc);
            } else {
                Vector v = new Vector();
                v.add(dc);
                rules.put(sym, v);
            }
        }
    }
}
