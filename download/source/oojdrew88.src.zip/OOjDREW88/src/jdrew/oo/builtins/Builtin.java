package jdrew.oo.builtins;

import jdrew.oo.util.*;

/**
 * <p>Title: OO jDREW</p>
 *
 * <p>Description: Reasoning Engine for the Semantic Web - Supporting OO RuleML
 * 0.88</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * @author Marcel A. Ball
 * @version 0.88
 */
public interface Builtin {
    public abstract DefiniteClause buildResult(Term t);

    public abstract int getSymbol();
}
